<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/fcm/index.ts#L18">
  Improve this doc
</a>

# FCM

```
$ ionic cordova plugin add cordova-plugin-fcm
$ npm install --save @ionic-native/fcm
```

## [Usage Documentation](https://ionicframework.com/docs/native/fcm/)

Plugin Repo: [https://github.com/fechanique/cordova-plugin-fcm](https://github.com/fechanique/cordova-plugin-fcm)

Provides basic functionality for Firebase Cloud Messaging

## Supported platforms
- Android
- iOS



