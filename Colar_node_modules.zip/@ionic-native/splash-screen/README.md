<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/splash-screen/index.ts#L1">
  Improve this doc
</a>

# Splash Screen

```
$ ionic cordova plugin add cordova-plugin-splashscreen
$ npm install --save @ionic-native/splash-screen
```

## [Usage Documentation](https://ionicframework.com/docs/native/splash-screen/)

Plugin Repo: [https://github.com/apache/cordova-plugin-splashscreen](https://github.com/apache/cordova-plugin-splashscreen)

This plugin displays and hides a splash screen during application launch. The methods below allows showing and hiding the splashscreen after the app has loaded.

## Supported platforms
- Amazon Fire OS
- Android
- BlackBerry 10
- iOS
- Tizen
- Ubuntu
- Windows
- Windows Phone



