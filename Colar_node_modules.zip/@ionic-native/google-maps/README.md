<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/google-maps/index.ts#L498">
  Improve this doc
</a>

# Google Maps

```
$ ionic cordova plugin add https://github.com/mapsplugin/cordova-plugin-googlemaps#multiple_maps --variable API_KEY_FOR_ANDROID="YOUR_ANDROID_API_KEY_IS_HERE" --variable API_KEY_FOR_IOS="YOUR_IOS_API_KEY_IS_HERE"
$ npm install --save @ionic-native/google-maps
```

## [Usage Documentation](https://ionicframework.com/docs/native/google-maps/)

Plugin Repo: [https://github.com/mapsplugin/cordova-plugin-googlemaps#multiple_maps](https://github.com/mapsplugin/cordova-plugin-googlemaps#multiple_maps)

This plugin uses the native Google Maps SDK
Note: As of Ionic native 4.0, this using the 2.0 version of the google maps plugin. Please make sure your plugin is updated

## Supported platforms
- Android
- iOS



