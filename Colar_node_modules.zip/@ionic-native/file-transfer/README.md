<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/file-transfer/index.ts#L106">
  Improve this doc
</a>

# File Transfer

```
$ ionic cordova plugin add cordova-plugin-file-transfer
$ npm install --save @ionic-native/file-transfer
```

## [Usage Documentation](https://ionicframework.com/docs/native/file-transfer/)

Plugin Repo: [https://github.com/apache/cordova-plugin-file-transfer](https://github.com/apache/cordova-plugin-file-transfer)

This plugin allows you to upload and download files.

## Supported platforms
- Amazon Fire OS
- Android
- Browser
- iOS
- Ubuntu
- Windows
- Windows Phone



