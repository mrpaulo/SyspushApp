<a style="float:right;font-size:12px;" href="http://github.com/ionic-team/ionic-native/edit/master/src/@ionic-native/plugins/status-bar/index.ts#L1">
  Improve this doc
</a>

# Status Bar

```
$ ionic cordova plugin add cordova-plugin-statusbar
$ npm install --save @ionic-native/status-bar
```

## [Usage Documentation](https://ionicframework.com/docs/native/status-bar/)

Plugin Repo: [https://github.com/apache/cordova-plugin-statusbar](https://github.com/apache/cordova-plugin-statusbar)

Manage the appearance of the native status bar.

Requires Cordova plugin: `cordova-plugin-statusbar`. For more info, please see the [StatusBar plugin docs](https://github.com/apache/cordova-plugin-statusbar).

## Supported platforms
- Android
- iOS
- Windows
- Windows Phone



